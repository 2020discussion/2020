from __future__ import division
from __future__ import print_function

import os
import glob
import time
import random
import argparse
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable

from utils import load_data, accuracy
from models import GAT, SpGAT

# Training settings
# 实例化一个解析对象parser
parser = argparse.ArgumentParser()
# 添加一系列默认的超参
# 辨识没有GPU的情况
parser.add_argument('--no-cuda', action='store_true', default=False, help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False, help='Validate during training pass.')
# 这里判断的是是否输入为稀疏矩阵
parser.add_argument('--sparse', action='store_true', default=False, help='GAT with sparse version or not.')
# 随机数种子？
parser.add_argument('--seed', type=int, default=72, help='Random seed.')
# 默认epoch轮
parser.add_argument('--epochs', type=int, default=10000, help='Number of epochs to train.')
# 默认学习速率
parser.add_argument('--lr', type=float, default=0.005, help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4, help='Weight decay (L2 loss on parameters).')
# 8个隐藏层
parser.add_argument('--hidden', type=int, default=8, help='Number of hidden units.')
# 注意力的head数
parser.add_argument('--nb_heads', type=int, default=8, help='Number of head attentions.')
# 抓包每次0.6
parser.add_argument('--dropout', type=float, default=0.6, help='Dropout rate (1 - keep probability).')
# 激活函数里面的alpha
parser.add_argument('--alpha', type=float, default=0.2, help='Alpha for the leaky_relu.')
# 能够忍受的最多多少次没有任何优化
parser.add_argument('--patience', type=int, default=100, help='Patience')

args = parser.parse_args()
args.cuda = not args.no_cuda and torch.cuda.is_available()

# 产生随机数，导入随机数种子
random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

# Load data，加载和预处理数据
adj, features, labels, idx_train, idx_val, idx_test = load_data()

# Model and optimizer
# 建立模型和优化，这里是adam优化。对于特征是否稀疏给与了两种模型
if args.sparse:
    # 调用init函数，初始化搭建好模型
    model = SpGAT(nfeat=features.shape[1], 
                nhid=args.hidden, 
                nclass=int(labels.max()) + 1, 
                dropout=args.dropout, 
                nheads=args.nb_heads, 
                alpha=args.alpha)
else:
    # 调用init函数，初始化搭建好模型
    model = GAT(nfeat=features.shape[1], 
                nhid=args.hidden, 
                nclass=int(labels.max()) + 1, 
                dropout=args.dropout, 
                nheads=args.nb_heads, 
                alpha=args.alpha)
# 定义梯度下降模型    
optimizer = optim.Adam(model.parameters(), 
                       lr=args.lr, 
                       weight_decay=args.weight_decay)

# 是否可以用显卡驱动
if args.cuda:
    model.cuda()
    features = features.cuda()
    adj = adj.cuda()
    labels = labels.cuda()
    idx_train = idx_train.cuda()
    idx_val = idx_val.cuda()
    idx_test = idx_test.cuda()

# Variable（）把向量转换为可变换的变量，即可以用来反向传播
features, adj, labels = Variable(features), Variable(adj), Variable(labels)


def train(epoch):
    # 记录训练开始时间
    t = time.time()
    # 训练模型
    model.train()
    # 优化
    optimizer.zero_grad()
    # Attention！在初始化结束后得到的model进行调用模型，此时调用的是forward函数，输入是零阶矩阵和特征编码
    output = model(features, adj)
    # 获得训练的损失值
    loss_train = F.nll_loss(output[idx_train], labels[idx_train])
    # 获得正确率
    acc_train = accuracy(output[idx_train], labels[idx_train])
    loss_train.backward()
    optimizer.step()

    if not args.fastmode:
        # Evaluate validation set performance separately,
        # deactivates dropout during validation run.
        model.eval()
        output = model(features, adj)
    # 获得损失和准确性
    loss_val = F.nll_loss(output[idx_val], labels[idx_val])
    acc_val = accuracy(output[idx_val], labels[idx_val])
    # output the information
    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.data.item()),
          'acc_train: {:.4f}'.format(acc_train.data.item()),
          'loss_val: {:.4f}'.format(loss_val.data.item()),
          'acc_val: {:.4f}'.format(acc_val.data.item()),
          'time: {:.4f}s'.format(time.time() - t))

    return loss_val.data.item()


def compute_test():
    model.eval()
    output = model(features, adj)
    loss_test = F.nll_loss(output[idx_test], labels[idx_test])
    acc_test = accuracy(output[idx_test], labels[idx_test])
    print("Test set results:",
          "loss= {:.4f}".format(loss_test.item()),
          "accuracy= {:.4f}".format(acc_test.item()))

# Train model
t_total = time.time()
loss_values = []
bad_counter = 0
# 记录每次的损失值
best = args.epochs + 1
# 记录下最好的一次epoch
best_epoch = 0
for epoch in range(args.epochs):
    # 记录每轮损失值
    loss_values.append(train(epoch))
    # 永久化存储model
    torch.save(model.state_dict(), '{}.pkl'.format(epoch))
    # 讲小于目前最小损失的轮数进行存储
    if loss_values[-1] < best:
        best = loss_values[-1]
        best_epoch = epoch
        bad_counter = 0
    else:
        bad_counter += 1
    # 连续100次没有优化直接停。
    if bad_counter == args.patience:
        break
    # 更改永久存储的文件名与内容
    files = glob.glob('*.pkl')
    for file in files:
        epoch_nb = int(file.split('.')[0])
        if epoch_nb < best_epoch:
            os.remove(file)

files = glob.glob('*.pkl')
for file in files:
    epoch_nb = int(file.split('.')[0])
    if epoch_nb > best_epoch:
        os.remove(file)

#训练完成，输出参数
print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

# Restore best model
print('Loading {}th epoch'.format(best_epoch))
model.load_state_dict(torch.load('{}.pkl'.format(best_epoch)))
torch.save(model, '{}.pth'.format(epoch))

# 测试
compute_test()
