import numpy as np
import scipy.sparse as sp
import torch


def encode_onehot(labels):
    classes = set(labels)
    classes_dict = {c: np.identity(len(classes))[i, :] for i, c in enumerate(classes)}
    labels_onehot = np.array(list(map(classes_dict.get, labels)), dtype=np.int32)
    return labels_onehot


def load_data(path="./data/cora/", dataset="cora"):
    """Load citation network dataset (cora only for now)"""
    print('Loading {} dataset...'.format(dataset))

    # genfromtxt 从content文件中读取数据。Cora数据是文献之间的引用网络。
    idx_features_labels = np.genfromtxt("{}{}.content".format(path, dataset), dtype=np.dtype(str))
    # read data，上面的数据是【id features label】，由于是左闭右开区间，所以这里直接读的全是features
    features = sp.csr_matrix(idx_features_labels[:, 1:-1], dtype=np.float32)
    print(features)
    print("hi")
    # 对标志进行one0hot编码
    labels = encode_onehot(idx_features_labels[:, -1])

    # build graph 存图，首先是将数据第一列paper_id读取出来，然后最后一段是论文分类标志
    idx = np.array(idx_features_labels[:, 0], dtype=np.int32)
    # 枚举所有的idx，将i，j组成map，对所有的文献id进行编号
    idx_map = {j: i for i, j in enumerate(idx)}
    # 从cite读取所有的无序边信息，该文件里存储的是全部的引用关系，前者是被引用，后者是引用
    edges_unordered = np.genfromtxt("{}{}.cites".format(path, dataset), dtype=np.int32)
    # 将cite文件里面未排序边的文献id对应为map里面的id，转换为在有序编号id之间建立的边的关系
    # map以前者的函数作用于后者的迭代数据
    edges = np.array(list(map(idx_map.get, edges_unordered.flatten())), dtype=np.int32).reshape(edges_unordered.shape)

    # print(adj.multiply)的out为
    # <bound method spmatrix.multiply of <2708x2708 sparse matrix of type '<class 'numpy.float32'>'
    # with 5429 stored elements in COOrdinate format>>
    # 由信息可见它的含义是建立了2708*2708大小的矩阵但是只有5429个有效数值，故是稀疏矩阵。
    # coo_matrix用法：
    # row = np.array([0, 3, 1, 0])
    # col = np.array([0, 3, 1, 2])
    # data = np.array([4, 5, 7, 9])
    # coo_matrix((data, (row, col)), shape=(4, 4)).toarray()
    # array([[4, 0, 9, 0],
    #        [0, 7, 0, 0],
    #        [0, 0, 0, 0],
    #        [0, 0, 0, 5]])
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])), shape=(labels.shape[0], labels.shape[0]),
                        dtype=np.float32)

    # build symmetric adjacency matrix ， 由邻接稀疏矩阵构建对称邻接矩阵
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    print(features)
    # 特征标准化
    features = normalize_features(features)
    print("hello")
    print(features)
    adj = normalize_adj(adj + sp.eye(adj.shape[0]))

    # 把前140条数据作为训练集，200到500为验证数据集，500到1500作为测试集
    idx_train = range(140)
    idx_val = range(200, 500)
    idx_test = range(500, 1500)

    # 把矩阵和one-hot编码变为pytorch支持的数据格式
    adj = torch.FloatTensor(np.array(adj.todense()))
    features = torch.FloatTensor(np.array(features.todense()))
    labels = torch.LongTensor(np.where(labels)[1])

    # 转换为pytorch支持的数据格式
    idx_train = torch.LongTensor(idx_train)
    idx_val = torch.LongTensor(idx_val)
    idx_test = torch.LongTensor(idx_test)

    # print(adj[1],features)
    # adj是邻接矩阵，features指的是把数值除以该文献为1的个数，比如0号有20个1每个1给0.05，labels是对7种分类的编码
    # 三种数据分类只是给了索引
    return adj, features, labels, idx_train, idx_val, idx_test


def normalize_adj(mx):
    """Row-normalize sparse matrix"""
    rowsum = np.array(mx.sum(1))
    r_inv_sqrt = np.power(rowsum, -0.5).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.
    # 将矩阵对角化
    r_mat_inv_sqrt = sp.diags(r_inv_sqrt)
    return mx.dot(r_mat_inv_sqrt).transpose().dot(r_mat_inv_sqrt)


def normalize_features(mx):
    """Row-normalize sparse matrix"""
    # attentionn 这里其实不太好懂，它的本质意思其实是在读出的features里面统计一行的1的个数。1为有关系
    print(mx)
    rowsum = np.array(mx.sum(1))
    print(rowsum)
    # 取数的倒数，变为0-1之间的数值
    r_inv = np.power(rowsum, -1).flatten()
    # 矩阵对角化并且将INF的数命为0
    r_inv[np.isinf(r_inv)] = 0.
    r_mat_inv = sp.diags(r_inv)
    # 再将两个矩阵乘起来 特征规范化
    mx = r_mat_inv.dot(mx)
    return mx


def accuracy(output, labels):
    preds = output.max(1)[1].type_as(labels)
    correct = preds.eq(labels).double()
    correct = correct.sum()
    return correct / len(labels)


if __name__ == '__main__':
    load_data()
